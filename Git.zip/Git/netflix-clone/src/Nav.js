import React from "react";
import "./Nav.css";
const Nav = () => {
  return (
    <nav className="">
      <div className="navbar flex drop-shadow-lg">
        <img
          src="https://ww1.freelogovectors.net/wp-content/uploads/2023/04/netflix-logo-freelogovectors.net_.png"
          alt="Netflix logo"
          className="mx-5"
        />
        <ul className="flex w-100 items-center">
          <li className="mx-2">About</li>
          <li className="mx-2">Movies</li>
        </ul>
      </div>
    </nav>
  );
};

export default Nav;
