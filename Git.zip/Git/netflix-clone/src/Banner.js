import axios from "./axios";
import React, { useEffect, useState } from "react";
import requests from "./requests";
import "./Banner.css";
const Banner = () => {
  let [movies, setMovies] = useState([]);
  useEffect(() => {
    let num = Math.floor(Math.random() * 19);
    console.log(num);
    const fetchData = async () => {
      const request = await axios.get(requests.fetchNetflixOriginals);
      setMovies(
        request.data.results[
          Math.floor(Math.random() * (request.data.results.length - 1))
        ]
      );
      console.log(movies.name);
    };
    fetchData();
  }, []);
  function truncate(str,n){
    return str?.length>n?str.substring(0,n-1)+" ...":str;
  }
  return (
    <header
      className="banner"
      style={{
        backgroundSize: "cover",
        background: `url(https://image.tmdb.org/t/p/original/${movies.backdrop_path})`,
        backgroundPosition: "center center",
      }}
    >
      <div className="banner_contents">
        <h1 className="banner_heading">
          {movies?.name || movies?.title || movies?.original_name}
        </h1>
        <p className="banner_description">{truncate(movies?.overview,150)}</p>
        <button className="banner_button w-32 text-black hover:bg-red-800 hover:text-white transition rounded-full p-2 me-2">Play</button>
        <button className="banner_button w-32 rounded-full hover:bg-gray-700 transition p-2 me-2">My List</button>
      </div>
      <div className="fadeBottom"></div>
    </header>
  );
};

export default Banner;
