import axios from "./axios";
import React, { useEffect, useState } from "react";
import "./Row.css";

const Row = (props) => {
  const [movies, setMovies] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      const request = await axios.get(props.fetchUrl);
      setMovies(request.data.results);
      console.log(request.data.results);
      return request;
    };
    fetchData();
  }, [props.fetchUrl]);

  return (
    <>
      <h1 className="text-white font-bold mx-5 text-xl">{props.title}</h1>
      <div className="row_posters p-5">
        {movies.map((movie) => (
          <div key={movie.id} className="m-2">
            <img
                className="row_poster"
              src={`https://image.tmdb.org/t/p/original/${props.isLargeRow?movie.poster_path:movie.backdrop_path}`}
              alt={movie.title}
            />
            
          </div>
        ))}
      </div>
    </>
  );
};

export default Row;
