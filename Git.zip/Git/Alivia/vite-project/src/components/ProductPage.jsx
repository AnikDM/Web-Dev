import {
  Box,
  Grid,
} from "@mui/material";
import monitor from '../assets/monitor1.png'
import SingleProduct from "./SingleProduct";
const ProductPage = () => {
  return (
    <div>
      <Box sx={{ flexGrow: 1 }}>
        <Grid container spacing={2} wrap='wrap'>
          <SingleProduct image={monitor} itemName="Msi Monitor"/>
          <SingleProduct image={monitor} itemName="Keyboard"/>
          <SingleProduct image={monitor} itemName="Mouse"/>
          <SingleProduct image={monitor} itemName="Intel i5"/>
        </Grid>
      </Box>
    </div>
  );
};

export default ProductPage;
