import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import PersonIcon from "@mui/icons-material/Person";
import FavoriteIcon from "@mui/icons-material/Favorite";
import ListIcon from "@mui/icons-material/List";
import "./NavbarPanel.css";
import {Drawer } from "@mui/material";
import { useState } from "react";
import { List, ListItem, ListItemButton, ListItemText } from "@mui/material";
import { Link } from "react-router-dom";
export default function NavbarPanel() {
  const [drawerState, setState] = useState(false);
  const handleOpen = () => setState(true);
  const handleClose = () => setState(false);
  return (
    <div className="shadow-lg flex justify-center mb-2">
      <div className=" navbar-panel flex items-center">
        <div className="flex text-center h-16 w-1/3 max-w-5xl justify-evenly">
          <a
            className="flex bg-orange-500 text-white items-center justify-center h-full w-full"
            href="#"
          >
            <button className="h-full" onClick={handleOpen}>
              <ListIcon />
              Categories
            </button>
            <Drawer anchor="left" open={drawerState} onClose={handleClose}>
                <List sx={{width:'15rem'}}>
                  {["Monitor", "Peripherals", "Processor", "RAM"].map(
                    (text) => (
                      <ListItem key={text} disablePadding>
                        <ListItemButton>
                          <ListItemText primary={text} />
                        </ListItemButton>
                      </ListItem>
                    )
                  )}
                </List>
            </Drawer>
          </a>
          <span
            className="flex hover:bg-orange-500 hover:text-white items-center justify-center h-full w-full"
            
          >
            Custom PC
          </span>
          <span
            className="flex hover:bg-orange-500 hover:text-white items-center justify-center h-full w-full"
            
          >
            Pre-Built PC
          </span>
          <span
            className="flex hover:bg-orange-500 hover:text-white items-center justify-center h-full w-full"
            
          >
            <Link to="/">Store</Link>
          </span>
        </div>
        <div className="w-2/3 text-end pe-9">
          <span className="mx-4">
            <PersonIcon />
          </span>
          <span className="mx-4">
            <FavoriteIcon />
          </span>
          <span className="mx-4">
            <Link to="/cart"><ShoppingCartIcon /></Link>
          </span>
        </div>
      </div>
    </div>
  );
}
