import {
    Button,
    CardActions,
    CardContent,
    Grid,
    Typography,
  } from "@mui/material";
import { styled } from "@mui/material/styles";
import Paper from "@mui/material/Paper";

const SingleProduct = ({image,itemName}) => {
    function handleClick(product){
        console.log(product);
    }
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: "center",
        color: theme.palette.text.secondary,
      }));
  return (
    <Grid item md={3}>
            <Item>         
                <CardContent>
                  <img src={image} alt="" />
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    {itemName}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button size="small" onClick={()=>{handleClick({img:image,item:itemName})}}>Add to Cart</Button>
                </CardActions>              
            </Item>
          </Grid>
  )
}

export default SingleProduct