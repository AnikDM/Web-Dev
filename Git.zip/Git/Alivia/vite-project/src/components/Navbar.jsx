import "./Navbar.css";
const Navbar = () => {
  return (
    <div className="shadow-lg flex justify-center">
      <nav className="m-0 navbar flex items-center justify-evenly margin-auto">
        <img
          className="rounded h-20"
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAHXPluq6GtTRPDIHRv5kJPy86uFjp5sO7hg&usqp=CAU"
          alt=""
        />
        <input
          className="rounded-full p-3 outline-none"
          type="search"
          name=""
          id=""
          placeholder="Search"
        />
        <div>
          <a href="#" className="mx-2">
            About
          </a>
          <a href="#" className="mx-2">
            Contact
          </a>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
