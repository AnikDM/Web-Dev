import React from 'react'
import { Link } from 'react-router-dom'

const CartPage = () => {
  return (
    <div>
        <Link></Link>
    </div>
  )
}

export default CartPage