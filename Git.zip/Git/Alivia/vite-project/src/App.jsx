import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Navbar from "./components/Navbar";
import NavbarPanel from "./components/NavbarPanel";
import ProductPage from "./components/ProductPage";
import CartPage from "./components/CartPage";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <NavbarPanel />
      <Routes>
        <Route path="/" exact element={<ProductPage />} />
        <Route path="/cart" exact element={<CartPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
