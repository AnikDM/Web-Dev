import './style.css'
import { generate, count } from "random-words";

let notation=document.getElementById('notation')
let word=document.getElementById('word')
let pos=document.getElementById('pos')
let meaning=document.getElementById('meaning')
let searchWord=document.getElementById('searchWord')
let example=document.getElementById('example')
let sound;
document.addEventListener('keypress',evt=>{
    console.log(evt.key);
    if(evt.key=='Enter'){
    console.log("inside ");
        fetchWord(searchWord.value);}
})
    
function fetchWord(keyword){
    console.log(keyword);
let fetchUrl=`https://api.dictionaryapi.dev/api/v2/entries/en/${keyword}`
fetch(fetchUrl).then(res=>{
   return res.json();
}).then(data=>{
    word.innerHTML=data[0].word ;
    notation.innerHTML=data[0].phonetics[0].text;
    showMeaning(data[0].meanings);
    pos.innerHTML=data[0].meanings[0].partOfSpeech;
    example.innerHTML="Example : "+data[0].meanings[0].definitions[0].example;
    sound=new Audio(data[0].phonetics[0].audio);

}).catch(err=>{
    alert('Cannot Find Your Word');
})
}
document.getElementById('play').addEventListener('click',()=>{
    console.log('inside');
    sound.play();
})

function showMeaning(arr){
    console.log(arr.length);
    let str="";
    arr.forEach(element => {
        str+="<li>"+element.definitions[0].definition+"</li>";
    });
    meaning.innerHTML=str;
    // data[0].meanings[0].definitions[0].definition
}

fetchWord(generate());
function handleRandom(){
    fetchWord(generate());
}
